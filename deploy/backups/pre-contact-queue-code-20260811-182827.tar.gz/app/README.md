# Dakings Prospect Ops

内部客户采集与邮件准备原型。应用直接读取项目现有网易采集 JSON，提供数据总览、采集流程、买家、联系人和邮件草稿工作区。

## 启动

在 PowerShell 中运行：

```powershell
& "D:\zcy\外贸自动化拓客系统\app\start.ps1"
```

默认地址：`http://127.0.0.1:4173`

可通过环境变量覆盖：

- `PORT`：服务端口。
- `HOST`：监听地址，默认仅本机。
- `SOURCE_PATH`：采集 JSON 路径。
- `CAMPAIGN_PATH`：本地邮件草稿存储路径。
- `PIPELINE_PATH`：HSCode九阶段流水线、租约、检查点与熔断状态。
- `OUTBOX_PATH`：发送前落盘的幂等发件箱与尝试事件。
- `RUNTIME_STATE_PATH`：OpenAI实际请求时间、成功时间和最近错误。
- `FEEDBACK_WEBHOOK_SECRET`：邮件服务商反馈回调的独立认证密钥；未配置时回调接口返回503。

## AI邮件起草

后端通过 OpenAI Responses API 生成主题和正文。密钥只从 `OPENAI_API_KEY`
读取，不会返回给浏览器，也不会写入活动文件。默认模型为 `gpt-5.6`，可用
`OPENAI_MODEL` 覆盖。配置项参考 `.env.example`。

AI生成与发送是两个独立动作：生成结果先进入可编辑草稿，之后仍需保存、预览、
提交审核。模型不会直接调用SMTP。

邮件实验室现支持首次开发信、工厂能力信、展会展位邀请、展会当地拜访和对参展商约见五个场景。每次起草必须提供HSCode、产品方向、采购商证据和我方能力；HSCode仅作内部匹配，不写入客户邮件。

33年经验、Walmart/National Geographic客户背书、OA账期、15天交期、工厂图和作品图都是受控卖点，默认禁止，只有人工勾选后才可生成或提交审核。

## 邮件配图

系统内置了用户提供的9组工厂/作品图。首次触达最多1张，展会场景最多2张。选图后必须确认对外使用权，预览会显示所选图片。受控SMTP发送使用multipart/alternative保留纯文本与HTML版，并以CID内嵌图片；不使用跟踪像素。

## SMTP发送门槛

真实发送默认关闭。只有同时满足以下条件时，活动页面才会显示发送按钮：

- `EMAIL_SENDING_ENABLED=true`，且SMTP主机、账号、密码、发件地址完整。
- 活动已提交审核。
- 发件域名、退订、实体地址和抑制名单四项均已人工确认。
- 已配置 `EMAIL_UNSUBSCRIBE_URL` 和 `EMAIL_PHYSICAL_ADDRESS`。
- 收件人邮箱已验证；如仅限内部测试，可显式设置 `EMAIL_ALLOW_UNVERIFIED=true`。

发送端点要求输入 `SEND <campaign-id>`，每次最多发送 `SEND_BATCH_LIMIT`
封，并按 `SEND_DELAY_MS` 间隔发送。发送结果仅保存收件邮箱哈希和数量，不把SMTP
密码写入审计记录。

## 当前能力

- 读取139家买家和前20大买家联系人数据。
- 买家搜索、国家、置信度和补全状态筛选。
- 联系人搜索、角色优先级、匹配置信度和唯一邮箱筛选。
- 本地邮件活动草稿、变量预览、提交审核和模拟排期。
- 场景化AI开发信、HSCode/采购商/联系人三层定制、受控卖点与配图预览。
- 本地审计记录。
- 反馈回调接收、幂等去重、发件箱关联，以及退订、投诉、硬退信自动永久抑制。

## 明确未实现

- 邮箱投递有效性验证。
- 联系人在职状态验证。
- 具体邮件服务商的Webhook字段适配、签名算法和生产回调地址配置。
- 收件箱同步、人工回复/自动回复内容分类和活动效果归因。
- DM Pro、CRM、网易营销任务或第三方上传。

通用 `/api/send` 仍固定返回锁定状态。真实发送只允许走带活动ID、审核状态、
合规检查和确认短语的 `/api/campaigns/:id/send`。

## 免费本地运行控制

以下能力不依赖付费服务，并且默认只写入 `app/data`：

- 邮箱格式与域名/MX检查：保存为 `syntax_valid`、`domain_valid` 或 `invalid`，不会把域名有效写成可投递。
- 当前联系人页可一次检查最多 25 个邮箱；同一域名在单批中只执行一次 DNS 查询，再把域名结果复用于该批邮箱。
- 人工验证状态导入：只有提供证据时才能写入 `deliverable`、`accept_all` 等状态。
- 永久抑制名单：邮箱只保存 SHA-256 指纹、域名、原因和来源；活动收件人会自动排除抑制记录。
- HSCode运行任务：冻结采购商/供应商方向、目标国家、买家条目预算、新公司详情预算和联系人分页预算。
- 九阶段流水线：`discovery -> trade_normalization -> buyer_matching -> contact_enrichment -> validation -> drafting -> approval -> sending -> feedback`；任务通过短租约领取，过期可恢复排队。
- 受限流水线执行器：`pipeline-worker.mjs` 只读取 `PIPELINE_INPUT_ROOT` 和 `PIPELINE_ARTIFACT_DIR` 内的 JSON；可自动完成 discovery、贸易归一和买家匹配，物流/中间商候选只标记不删除。
- 联系人阶段输入门槛：只有导入 `kind=netease-contact-enrichment` 的可追溯 JSON 才会生成“人物联系人”和“公司联系方式”数据；缺少输入时停在 `waiting_input`。
- 输入门槛：创建HSCode任务后默认为 `waiting_input`，必须登记网易正常页面结果或已导入文件引用才可排队。
- 检查点与熔断：验证码、操作频繁、权限提示、403/429立即进入 `CIRCUIT_OPEN`；结构/分页异常连续三次熔断；恢复需要 `RECOVER <task-id>` 确认短语并回到金丝雀预算。
- 任务审计与导出：界面显示最近 20 条动作，并可导出当前任务 JSON。
- 本地控制备份：导出邮箱验证、抑制、任务审计和活动草稿，不包含密钥、Cookie或原始联系人数据；备份附带 SHA-256 完整性摘要。
- 备份恢复预检：运行控制页可选择导出的 JSON 校验版本、结构、记录上限、邮箱哈希和完整性摘要，但不会自动恢复或覆盖现有数据。应直接校验原始导出文件；经表格软件或其他工具改写后，完整性摘要会失效并被拒绝。
- 安全合并恢复：预览新增与冲突数量后，输入 `MERGE <摘要前缀>` 才执行；写入前自动保存回滚快照。合并只添加缺失记录，同标识记录始终保留当前版本，因此永久抑制、任务计数、熔断状态和发送历史不会被旧备份回滚。破坏性覆盖恢复仍未开放。
- 幂等发件箱：SMTP连接前写入 `pending`，尝试前写入 `sending`，服务器接受后写入 `accepted`。DATA提交后无法确认结果时写入 `uncertain`，必须人工裁决，不得自动重试。
- 邮件反馈入口：`POST /api/feedback/events` 支持 `unsubscribe`、`complaint`、`hard_bounce`、`soft_bounce`、`reply` 和 `auto_reply`。使用 `eventId + x-feedback-source` 幂等；只保存收件邮箱SHA-256，不保存明文邮箱。退订、投诉和硬退信会立即进入永久抑制名单。

对应数据文件：

- `app/data/contact-validation.json`
- `app/data/suppressions.json`
- `app/data/operations.json`
- `app/data/pipeline.json`
- `app/data/outbox.json`
- `app/data/runtime-state.json`

## API

本地控制接口：

- `GET /api/contact-quality`
- `POST /api/contact-quality/validate`
- `POST /api/contact-quality/status`
- `GET|POST /api/suppressions`
- `GET|POST /api/ops/tasks`
- `GET /api/ops/tasks/:id`
- `POST /api/ops/tasks/:id/actions`
- `POST /api/ops/tasks/:id/recover`
- `GET /api/pipeline`
- `POST /api/pipeline/claim-next`
- `POST /api/pipeline/jobs/:id/resume`
- `POST /api/pipeline/jobs/:id/stage`
- `POST /api/pipeline/jobs/:id/pause|circuit|recover`
- `GET /api/outbox`
- `POST /api/outbox/:id/resolve`
- `POST /api/feedback/events`
- `GET /api/local-backup`
- `POST /api/local-backup/validate`
- `POST /api/local-backup/preview`
- `POST /api/local-backup/merge`

- `GET /api/health`
- `GET /api/summary`
- `GET /api/quality`（本地数据质量报告：买家覆盖、联系人可用性、重复、邮箱格式和发送前风险）
- `GET /api/workflow`
- `GET /api/buyers`
- `GET /api/contacts`
- `GET /api/options`
- `GET|POST /api/campaigns`
- `PUT /api/campaigns/:id`
- `POST /api/campaigns/:id/preview`
- `POST /api/campaigns/:id/submit-review`
- `POST /api/campaigns/:id/approve`（需要 `APPROVE <campaign-id>` 确认短语；通过内容、合规和名单门槛后才进入 approved）
- `POST /api/campaigns/:id/simulate-schedule`
- `POST /api/ai/draft`
- `POST /api/campaigns/:id/send`

## 邮件反馈回调

反馈入口默认关闭。配置独立的 `FEEDBACK_WEBHOOK_SECRET` 后，服务商适配器应发送：

```http
POST /api/feedback/events
Content-Type: application/json
X-Feedback-Secret: <dedicated webhook secret>
X-Feedback-Source: <provider name>

{"eventId":"provider-event-id","type":"complaint","email":"recipient@example.com","messageId":"provider-message-id","occurredAt":"2026-08-04T12:00:00Z"}
```

也可以发送64位小写SHA-256 `recipientHash` 代替邮箱。接口按 `messageId` 优先、收件人哈希其次关联幂等发件箱；重复事件返回200和 `duplicate=true`，新事件返回202。该通用入口不等于服务商已经完成对接：上线前仍需按所选SMTP/ESP的实际签名和字段编写适配器，并完成一次真实回调金丝雀。

## External purchase and authorization gates

The **System Boundary** page is the source of truth for local readiness and external blockers. The following items are intentionally not simulated by the app:

- 网易账号不是购买项：使用业务方提供的网易外贸账号现场登录并保持正常页面会话。
- 邮箱验证：在职/可投递验证服务订阅，或可追溯的人工验证证据。
- 发件基础设施：发件域名、SMTP credentials, SPF/DKIM/DMARC and bounce handling.
- 合规与业务授权：unsubscribe URL, physical sender address, suppression-list/CRM permissions, approved business claims and image rights.

Administrator access to this computer is not currently required. It cannot replace an external subscription, domain configuration or business approval. `syntax_valid` and `domain_valid` are local checks only; they do not assert deliverability. Real sending remains locked unless SMTP, compliance fields, validation evidence and explicit batch approval are all present.

## Pipeline worker

本地单次处理一个阶段：

```powershell
$env:PIPELINE_API_BASE = "http://127.0.0.1:4173"
$env:PIPELINE_INPUT_ROOT = "D:\zcy\外贸自动化拓客系统\outputs"
$env:PIPELINE_ARTIFACT_DIR = "D:\zcy\外贸自动化拓客系统\app\data\pipeline-artifacts"
node app/pipeline-worker.mjs --drain --max-jobs 6
```

执行器不保存网易 Cookie、不调用未公开接口，也不自行处理验证码。网易可见页面结果应先按 `netease-customs-discovery` 格式落盘，再通过流水线 `resume` 接口登记文件引用。生产发送、OpenAI 出口、邮箱可投递验证和联系人在职验证仍是独立门槛。
