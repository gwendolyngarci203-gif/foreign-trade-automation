const state = {
  view: "overview",
  health: null,
  summary: null,
  quality: null,
  workflow: [],
  options: { countries: [], confidences: [], priorities: [], enrichedBuyers: [], variables: [], emailScenarios: [], emailClaims: [], emailAssets: [] },
  buyers: null,
  contacts: null,
  contactQuality: { counts: {}, records: [], storedRecords: 0, suppressions: 0 },
  suppressions: { count: 0, items: [] },
  operationTasks: [],
  pipeline: { stages: [], counts: {}, claimable: 0, jobs: [] },
  outbox: { counts: {}, items: [] },
  selectedTaskId: null,
  campaigns: [],
  buyerFilters: { q: "", country: "", confidence: "", status: "", page: 1, pageSize: 20 },
  contactFilters: { q: "", buyer: "", priority: "", confidence: "", validation: "", dedupe: "first", emailOnly: false, page: 1, pageSize: 25 },
  campaignPreview: null,
};

const viewMeta = {
  overview: ["采集运营", "数据总览"],
  workflow: ["端到端状态", "采集流程"],
  buyers: ["139家原始买家", "买家工作台"],
  contacts: ["前20大买家", "联系人"],
  operations: ["预算与安全状态", "运行控制"],
  campaigns: ["未来发送流程", "邮件实验室"],
  settings: ["安全与合规", "系统边界"],
};

const main = document.getElementById("mainContent");
const title = document.getElementById("viewTitle");
const eyebrow = document.getElementById("viewEyebrow");
const sidebar = document.getElementById("sidebar");
const scrim = document.getElementById("mobileScrim");

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function currency(value) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 2 }).format(Number(value || 0));
}

function number(value) {
  return new Intl.NumberFormat("zh-CN").format(Number(value || 0));
}

function percent(value) {
  return `${Number(value || 0).toFixed(2)}%`;
}

function shortDate(value) {
  if (!value) return "-";
  return new Intl.DateTimeFormat("zh-CN", { year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date(value));
}

function shortDateTime(value) {
  if (!value) return "-";
  return new Intl.DateTimeFormat("zh-CN", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).format(new Date(value));
}

function queryString(values) {
  const query = new URLSearchParams();
  Object.entries(values).forEach(([key, value]) => {
    if (value !== "" && value !== false && value != null) query.set(key, value);
  });
  return query.toString();
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.details?.join("；") || payload.errors?.join("；") || payload.error || `请求失败 ${response.status}`);
  return payload;
}

function badge(value) {
  const map = {
    "高": "high", "中高": "medium", "中": "medium", "低": "low", "未匹配": "neutral",
    complete: "complete", partial: "partial", blocked: "blocked", prototype: "prototype",
    draft: "draft", review: "review", approved: "approved", simulated_scheduled: "scheduled",
    partially_sent: "partial", sent: "complete",
    "已补全": "complete", "待补全": "neutral",
    READY: "complete", RUNNING: "complete", THROTTLED: "partial", CIRCUIT_OPEN: "blocked", HUMAN_RECOVERY: "prototype",
    queued: "neutral", running: "complete", waiting_input: "partial", circuit_open: "blocked", paused: "prototype", completed: "complete",
    pending: "neutral", sending: "partial", accepted: "complete", failed: "blocked", uncertain: "blocked",
    unverified: "neutral", syntax_valid: "partial", domain_valid: "complete", deliverable: "complete",
    accept_all: "partial", invalid: "blocked", opted_out: "blocked",
  };
  const labels = {
    complete: "已完成", partial: "进行中", blocked: "待解锁", prototype: "原型",
    draft: "草稿", review: "审核中", approved: "已批准", simulated_scheduled: "模拟排期",
    partially_sent: "部分已发送", sent: "发送完成",
    READY: "就绪", RUNNING: "运行中", THROTTLED: "已降速", CIRCUIT_OPEN: "已熔断", HUMAN_RECOVERY: "人工恢复",
    queued: "排队中", running: "执行中", waiting_input: "待输入", circuit_open: "已熔断", paused: "已暂停", completed: "已完成",
    pending: "待发送", sending: "发送中", accepted: "已接受", failed: "失败", uncertain: "状态不确定",
    unverified: "未验证", syntax_valid: "格式有效", domain_valid: "域名有效", deliverable: "可投递",
    accept_all: "全收域名", invalid: "无效", opted_out: "已抑制",
  };
  return `<span class="badge ${map[value] || "neutral"}">${escapeHtml(labels[value] || value || "-")}</span>`;
}

function toast(message, type = "success") {
  const item = document.createElement("div");
  item.className = `toast ${type === "error" ? "error" : ""}`;
  item.textContent = message;
  document.getElementById("toastRegion").appendChild(item);
  window.setTimeout(() => item.remove(), 3200);
}

function refreshIcons() {
  if (window.lucide) window.lucide.createIcons();
}

function setLoading() {
  main.innerHTML = `<div class="loading-state"><div class="spinner"></div><span>正在读取数据</span></div>`;
}

function emptyState(icon, titleText, body) {
  return `<div class="empty-state"><div><i data-lucide="${icon}"></i><strong>${escapeHtml(titleText)}</strong><p>${escapeHtml(body)}</p></div></div>`;
}

async function loadBase() {
  const [health, summary, quality, workflowData, options, buyers, contacts, contactQuality, suppressions, operations, pipeline, outbox, campaigns] = await Promise.all([
    api("/api/health"),
    api("/api/summary"),
    api("/api/quality"),
    api("/api/workflow"),
    api("/api/options"),
    api("/api/buyers?page=1&pageSize=10"),
    api("/api/contacts?page=1&pageSize=25&dedupe=first"),
    api("/api/contact-quality"),
    api("/api/suppressions"),
    api("/api/ops/tasks"),
    api("/api/pipeline"),
    api("/api/outbox"),
    api("/api/campaigns"),
  ]);
  state.health = health;
  state.summary = summary;
  state.quality = quality;
  state.workflow = workflowData.items;
  state.options = options;
  state.buyers = buyers;
  state.contacts = contacts;
  state.contactQuality = contactQuality;
  state.suppressions = suppressions;
  state.operationTasks = operations.items;
  state.pipeline = pipeline;
  state.outbox = outbox;
  state.selectedTaskId ||= operations.items[0]?.id || null;
  state.campaigns = campaigns;
}

function renderOverview() {
  const s = state.summary;
  const q = state.quality || { metrics: {}, issues: [] };
  const topBuyers = state.buyers.items.slice(0, 8);
  const stage = state.workflow.find((item) => item.id === "matching");
  return `
    <div class="view-stack">
      <section class="kpi-grid" aria-label="关键指标">
        ${kpi("circle-dollar-sign", "英文主体成交额", currency(s.supplierAmountUsd), `${number(s.supplierTradeCount)} 笔 · 最近 ${s.lastTradeDate}`)}
        ${kpi("building-2", "已验证买家", number(s.buyerCount), `前20覆盖金额 ${percent(s.top20CoveragePct)}`)}
        ${kpi("contact-round", "去重可联系对象", number(s.uniqueContacts), `${number(s.uniqueEmails)} 邮箱 · ${number(s.uniquePhones)} 电话`)}
        ${kpi("scan-search", "买家补全进度", `${s.enrichedBuyerCount}/${s.buyerCount}`, `${stage.progress}% 买家数 · ${percent(s.top20CoveragePct)} 金额覆盖`)}
      </section>

      <section class="split-layout">
        <div class="panel">
          <div class="panel-head"><h3>高价值买家</h3><button class="button small" data-jump="buyers" type="button"><i data-lucide="arrow-right"></i>全部买家</button></div>
          <div class="mini-metrics">
            <div class="mini-metric"><span>前20成交额</span><strong>${currency(s.top20AmountUsd)}</strong></div>
            <div class="mini-metric"><span>原始联系人行</span><strong>${number(s.extractedContactRows)}</strong></div>
            <div class="mini-metric"><span>重复关联</span><strong>${number(s.duplicateLinks)}</strong></div>
            <div class="mini-metric"><span>低置信匹配</span><strong>${number(s.lowConfidence)}</strong></div>
            <div class="mini-metric"><span>质量问题</span><strong>${number(q.issues.length)}</strong></div>
          </div>
          <div class="table-shell">
            <table>
              <thead><tr><th>买家</th><th>国家</th><th class="number">成交额</th><th class="number">交易</th><th>补全</th><th class="number">联系人</th></tr></thead>
              <tbody>${topBuyers.map((item) => `
                <tr>
                  <td class="company-cell"><strong>${escapeHtml(item.buyer)}</strong><span>${escapeHtml(item.matchedCompany || "待匹配")}</span></td>
                  <td>${escapeHtml(item.country)}</td>
                  <td class="number">${currency(item.amountUsd)}</td>
                  <td class="number">${number(item.tradeCount)}</td>
                  <td>${badge(item.matchConfidence)}</td>
                  <td class="number">${number(item.accessibleContacts)}</td>
                </tr>`).join("")}</tbody>
            </table>
          </div>
        </div>

        <aside class="panel">
          <div class="panel-head"><h3>风险与下一关卡</h3></div>
          <div class="panel-body">
            <ul class="risk-list">
              ${risk("scale", "金额口径未调平", `供应商汇总与买家行合计相差 ${currency(s.reconciliationDifferenceUsd)}。`)}
              ${risk("copy", "别名重复", `Boardstreet 与 Broadstreet 造成 ${number(s.duplicateLinks)} 条联系人重复关联。`)}
              ${risk("mail-warning", "邮箱尚未验证", `${number(s.uniqueEmails)} 个唯一邮箱仍为 unverified，不能进入真实发送。`)}
              ${risk("shield-alert", "发送功能锁定", "需先完成域名、退订、抑制名单和退信处理。")}
              ${risk("clipboard-check", "质量报告", `${number(q.issues.length)} 项待处理；邮箱默认仍是 unverified。`)}
            </ul>
          </div>
        </aside>
      </section>
    </div>`;
}

function kpi(icon, label, value, foot) {
  return `<article class="kpi-card"><div class="kpi-head"><span>${escapeHtml(label)}</span><span class="kpi-icon"><i data-lucide="${icon}"></i></span></div><div class="kpi-value">${value}</div><div class="kpi-foot">${escapeHtml(foot)}</div></article>`;
}

function risk(icon, heading, body) {
  return `<li class="risk-item"><span class="risk-icon"><i data-lucide="${icon}"></i></span><div><strong>${escapeHtml(heading)}</strong><p>${escapeHtml(body)}</p></div></li>`;
}

function renderWorkflow() {
  return `
    <div class="view-stack">
      <div class="section-header"><div><h2>群发前七阶段</h2><p>阶段状态来自当前采集成果，邮件真实发送保持锁定。</p></div><div class="section-actions">${badge("prototype")}</div></div>
      <section class="panel">
        <div class="workflow-list">
          ${state.workflow.map((item) => `
            <article class="workflow-row ${item.status}">
              <div class="stage-number">${item.order}</div>
              <div class="stage-title"><strong>${escapeHtml(item.name)}</strong><span>${badge(item.status)}</span></div>
              <div class="stage-output">${escapeHtml(item.output)}</div>
              <div><div class="progress-track"><div class="progress-fill ${item.status === "blocked" ? "red" : item.progress < 100 ? "amber" : ""}" style="width:${item.progress}%"></div></div><div class="kpi-foot">${item.progress}%</div></div>
            </article>`).join("")}
        </div>
      </section>
      <div class="callout"><i data-lucide="circle-stop"></i><div><strong>当前阻塞点：邮箱有效性和在职状态</strong><span>联系人已完成结构化与去重，但尚未接入邮箱投递验证，也没有人工确认全部联系人是否在职。</span></div></div>
    </div>`;
}

function selectOptions(items, selected, allLabel) {
  return `<option value="">${escapeHtml(allLabel)}</option>${items.map((item) => `<option value="${escapeHtml(item)}" ${item === selected ? "selected" : ""}>${escapeHtml(item)}</option>`).join("")}`;
}

function renderBuyers() {
  const result = state.buyers;
  return `
    <div class="view-stack">
      <div class="section-header"><div><h2>买家原始记录与补全状态</h2><p>保留139家原始报关买家，补全结果不会改写原名称。</p></div><div class="section-actions"><span class="badge neutral">${number(result.total)} 条</span></div></div>
      <section class="panel">
        <form class="toolbar" id="buyerFilterForm">
          <div class="field"><label for="buyerSearch">公司搜索</label><input class="input" id="buyerSearch" name="q" value="${escapeHtml(state.buyerFilters.q)}" placeholder="买家、匹配公司或官网" /></div>
          <div class="field"><label for="buyerCountry">国家/地区</label><select class="select" id="buyerCountry" name="country">${selectOptions(state.options.countries, state.buyerFilters.country, "全部国家")}</select></div>
          <div class="field"><label for="buyerConfidence">匹配置信度</label><select class="select" id="buyerConfidence" name="confidence">${selectOptions(state.options.confidences, state.buyerFilters.confidence, "全部置信度")}</select></div>
          <div class="field"><label for="buyerStatus">补全状态</label><select class="select" id="buyerStatus" name="status">${selectOptions(["已补全", "待补全"], state.buyerFilters.status, "全部状态")}</select></div>
          <button class="button primary" type="submit"><i data-lucide="search"></i>筛选</button>
        </form>
        <div class="table-shell">
          <table>
            <thead><tr><th>买家</th><th>国家</th><th class="number">成交额</th><th class="number">份额</th><th>最近交易</th><th class="number">次数</th><th>补全</th><th>匹配公司</th><th class="number">可联系</th></tr></thead>
            <tbody>${result.items.map((item) => `
              <tr>
                <td class="company-cell"><strong>${escapeHtml(item.buyer)}</strong><span>${item.buyerRank ? `金额排名 #${item.buyerRank}` : `原始序号 #${item.sourceIndex}`}</span></td>
                <td>${escapeHtml(item.country)}</td><td class="number">${currency(item.amountUsd)}</td><td class="number">${percent(item.sharePct)}</td>
                <td>${escapeHtml(item.lastTradeDate || "-")}</td><td class="number">${number(item.tradeCount)}</td><td>${badge(item.enrichmentStatus)}</td>
                <td class="company-cell"><strong>${escapeHtml(item.matchedCompany || "待补全")}</strong><span>${badge(item.matchConfidence)} ${item.website && item.website !== "-" ? `<a href="${escapeHtml(item.website)}" target="_blank" rel="noreferrer">官网</a>` : ""}</span></td>
                <td class="number">${number(item.accessibleContacts)}</td>
              </tr>`).join("")}</tbody>
          </table>
        </div>
        ${pagination("buyers", result)}
      </section>
    </div>`;
}

function renderContacts() {
  const result = state.contacts;
  const buyerNames = state.options.enrichedBuyers || [];
  const checkableCount = result.items.filter((item) => item.email && !item.suppressed).length;
  return `
    <div class="view-stack">
      <div class="section-header"><div><h2>去重联系人工作台</h2><p>基础检查只验证格式与域名，不代表邮箱可投递或联系人仍在职。</p></div><div class="section-actions"><span class="badge neutral">${number(result.total)} 条匹配</span><button class="button" id="validatePageButton" type="button" ${checkableCount ? "" : "disabled"}><i data-lucide="scan-search"></i>检查本页 ${number(checkableCount)} 个邮箱</button></div></div>
      <section class="panel">
        <form class="toolbar contact-toolbar" id="contactFilterForm">
          <div class="field"><label for="contactSearch">联系人搜索</label><input class="input" id="contactSearch" name="q" value="${escapeHtml(state.contactFilters.q)}" placeholder="姓名、职位、公司或邮箱" /></div>
          <div class="field"><label for="contactBuyer">买家</label><select class="select" id="contactBuyer" name="buyer">${selectOptions(buyerNames, state.contactFilters.buyer, "当前页全部买家")}</select></div>
          <div class="field"><label for="contactPriority">角色优先级</label><select class="select" id="contactPriority" name="priority">${selectOptions(state.options.priorities, state.contactFilters.priority, "全部角色")}</select></div>
          <div class="field"><label for="contactConfidence">匹配置信度</label><select class="select" id="contactConfidence" name="confidence">${selectOptions(state.options.confidences, state.contactFilters.confidence, "全部置信度")}</select></div>
          <div class="field"><label for="contactValidation">邮箱状态</label><select class="select" id="contactValidation" name="validation">${selectOptions(["unverified", "syntax_valid", "domain_valid", "deliverable", "accept_all", "invalid", "opted_out"], state.contactFilters.validation, "全部状态")}</select></div>
          <button class="button primary" type="submit"><i data-lucide="list-filter"></i>筛选</button>
        </form>
        <div class="panel-head">
          <label class="check-row"><input id="emailOnlyToggle" type="checkbox" ${state.contactFilters.emailOnly ? "checked" : ""} />仅唯一邮箱</label>
          <div class="callout"><i data-lucide="badge-alert"></i><div><strong>${number(state.contactQuality.storedRecords)} 条本地验证 · ${number(state.suppressions.count)} 条永久抑制</strong><span>域名有效不等于邮箱可投递；deliverable 必须有人工或验证服务证据。</span></div></div>
        </div>
        <div class="table-shell">
          <table>
            <thead><tr><th>联系人</th><th>角色</th><th>买家与国家</th><th>邮箱</th><th>验证</th><th>电话</th><th>LinkedIn</th><th>来源</th><th>匹配</th><th>操作</th></tr></thead>
            <tbody>${result.items.map((item) => `
              <tr>
                <td class="contact-cell"><strong>${escapeHtml(item.name || "公共联系方式")}</strong><span>${escapeHtml(item.title || "未标注职位")}</span></td>
                <td>${badge(item.priority.startsWith("A-") ? "高" : item.priority.startsWith("B-") ? "中高" : "未匹配")}<div class="kpi-foot">${escapeHtml(item.priority)}</div></td>
                <td class="company-cell"><strong>${escapeHtml(item.rawBuyerName)}</strong><span>${escapeHtml(item.country)} · ${currency(item.amountUsd)}</span></td>
                <td class="contact-cell"><strong>${escapeHtml(item.email || "-")}</strong><span>${item.validationCheckedAt ? `检查 ${shortDate(item.validationCheckedAt)}` : "未执行本地检查"}</span></td>
                <td>${item.email ? badge(item.validationStatus) : "-"}</td>
                <td>${escapeHtml(item.phone || "-")}</td>
                <td>${item.linkedin ? `<a class="button small" href="${escapeHtml(item.linkedin)}" target="_blank" rel="noreferrer"><i data-lucide="linkedin"></i>档案</a>` : "-"}</td>
                <td>${escapeHtml(item.source || "-")}</td><td>${badge(item.matchConfidence)}</td>
                <td><div class="row-actions">${item.email ? `<button class="icon-button" data-validate-email="${escapeHtml(item.email)}" title="执行本地格式与域名检查" aria-label="验证邮箱"><i data-lucide="shield-check"></i></button><button class="icon-button danger" data-suppress-email="${escapeHtml(item.email)}" title="加入永久抑制名单" aria-label="抑制邮箱"><i data-lucide="ban"></i></button>` : "-"}</div></td>
              </tr>`).join("")}</tbody>
          </table>
        </div>
        ${pagination("contacts", result)}
      </section>
    </div>`;
}

function pagination(kind, result) {
  return `<div class="pagination"><span>第 ${result.page}/${result.pages} 页 · 共 ${number(result.total)} 条</span><div class="pagination-actions"><button class="button small" data-page-kind="${kind}" data-page="${result.page - 1}" ${result.page <= 1 ? "disabled" : ""}><i data-lucide="chevron-left"></i>上一页</button><button class="button small" data-page-kind="${kind}" data-page="${result.page + 1}" ${result.page >= result.pages ? "disabled" : ""}>下一页<i data-lucide="chevron-right"></i></button></div></div>`;
}

function auditActionLabel(item) {
  const labels = {
    task_created: "任务创建",
    buyer_entry: "买家条目",
    company_search: "公司搜索",
    company_detail: "公司详情",
    contact_page: "联系人分页",
    raw_contact_row: "联系人行",
    checkpoint: "保存检查点",
    budget_rejected: "预算拒绝",
    human_recovery_confirmed: "人工恢复",
  };
  return labels[item.type] || item.type || "未知动作";
}

function auditCountLabel(item) {
  if (item.type === "budget_rejected") return `${number(item.requestedCount)}（当前 ${number(item.currentCount)} / 上限 ${number(item.budget)}）`;
  return item.count == null ? "-" : number(item.count);
}

function pipelineStageLabel(stage) {
  return {
    discovery: "HSCode检索",
    trade_normalization: "贸易记录标准化",
    buyer_matching: "采购商识别",
    contact_enrichment: "联系人补全",
    validation: "邮箱验证",
    drafting: "客制化起草",
    approval: "人工审批",
    sending: "受控发送",
    feedback: "反馈回写",
  }[stage] || stage || "-";
}

function aiRuntimeState() {
  const ai = state.health?.ai || {};
  if (!ai.configured) return { ready: false, status: "blocked", label: "未配置API密钥" };
  if (ai.reachable === false) return { ready: true, status: "blocked", label: `已配置但网络不可达${ai.lastError ? `：${ai.lastError}` : ""}` };
  if (ai.reachable === true) return { ready: true, status: "complete", label: `生产请求成功 · ${shortDateTime(ai.lastSuccessAt)}` };
  return { ready: true, status: "partial", label: "已配置，尚未完成生产连通验证" };
}

function renderOperations() {
  const tasks = state.operationTasks || [];
  const selected = tasks.find((item) => item.id === state.selectedTaskId) || tasks[0] || null;
  const selectedPipeline = state.pipeline.jobs.find((item) => item.operationTaskId === selected?.id) || null;
  const counters = selected?.counters || {};
  const budgets = selected?.budgets || {};
  const remaining = (used, limit) => Math.max(Number(limit || 0) - Number(used || 0), 0);
  return `
    <div class="view-stack">
      <div class="section-header"><div><h2>HSCode流水线、动作预算与熔断</h2><p>系统持久化排队、阶段和检查点；网易检索仍只走正常登录页面，缺少输入时自动停在待输入状态。</p></div><div class="section-actions"><button class="button" id="validateBackupButton" type="button"><i data-lucide="file-check-2"></i>校验备份</button><button class="button" id="mergeBackupButton" type="button"><i data-lucide="history"></i>安全合并备份</button><button class="button" id="exportBackupButton" type="button"><i data-lucide="archive"></i>导出控制备份</button>${selected ? `<button class="button" id="exportTaskButton" type="button"><i data-lucide="file-down"></i>导出任务</button>${badge(selected.safetyState)}` : badge("READY")}</div></div>
      <section class="kpi-grid" aria-label="运行控制指标">
        ${kpi("list-tree", "本地任务", number(tasks.length), `${number(tasks.filter((item) => item.status === "active").length)} 个运行中`)}
        ${kpi("workflow", "流水线队列", number(state.pipeline.jobs.length), `${number(state.pipeline.claimable)} 个可领取 · ${number(state.pipeline.counts?.waiting_input || 0)} 个待输入`)}
        ${kpi("mail-check", "本地验证", number(state.contactQuality.storedRecords), `${number(state.contactQuality.counts?.domain_valid || 0)} 个域名有效`)}
        ${kpi("ban", "永久抑制", number(state.suppressions.count), "退订、投诉、硬退信和手工禁联")}
        ${kpi("mailbox", "持久发件箱", number(state.outbox.items.length), `${number(state.outbox.counts?.accepted || 0)} 已接受 · ${number(state.outbox.counts?.uncertain || 0)} 待裁决`)}
      </section>

      <section class="split-layout ops-layout">
        <div class="panel">
          <div class="panel-head"><h3>创建冻结任务</h3><span class="badge neutral">只接受HSCode</span></div>
          <form class="panel-body editor" id="opsTaskForm">
            <div class="form-grid"><div class="field"><label for="opsHsCode">HSCode</label><input class="input" id="opsHsCode" name="hsCode" inputmode="numeric" pattern="[0-9]{4,10}" value="4903000" required /></div><div class="field"><label for="opsDirection">方向</label><select class="select" id="opsDirection" name="direction"><option value="buyer">采购商</option><option value="supplier">供应商</option></select></div></div>
            <div class="field"><label for="opsCountries">目标国家/地区（逗号分隔，可留空）</label><input class="input" id="opsCountries" name="countries" placeholder="United States, Mexico" /></div>
            <div class="form-grid"><div class="field"><label for="buyerBudget">买家条目/日</label><input class="input" id="buyerBudget" name="buyerBudget" type="number" min="1" max="2000" value="100" /></div><div class="field"><label for="detailBudget">新公司详情/日</label><input class="input" id="detailBudget" name="detailBudget" type="number" min="1" max="40" value="5" /></div></div>
            <div class="field"><label for="contactPageBudget">联系人分页动作/日</label><input class="input" id="contactPageBudget" name="contactPageBudget" type="number" min="1" max="300" value="25" /></div>
            <button class="button primary" type="submit"><i data-lucide="plus"></i>创建任务</button>
          </form>
        </div>

        <div class="panel">
          <div class="panel-head"><h3>本地任务</h3><span class="badge neutral">${number(tasks.length)} 个</span></div>
          <div class="task-list">${tasks.length ? tasks.map((task) => `
            <button class="task-row ${task.id === selected?.id ? "active" : ""}" data-select-task="${escapeHtml(task.id)}" type="button">
              <span><strong>${escapeHtml(task.hsCode)}</strong><small>${task.direction === "buyer" ? "采购商" : "供应商"} · ${escapeHtml(task.countries.join(", ") || "全部地区")}</small></span>
              <span>${badge(task.safetyState)}<small>${escapeHtml(task.counters.businessDate)}</small></span>
            </button>`).join("") : emptyState("list-plus", "暂无任务", "先创建一个只使用HSCode的冻结任务。")}</div>
        </div>
      </section>

      ${selectedPipeline ? `<section class="panel pipeline-panel">
        <div class="panel-head"><div><h3>端到端流水线</h3><p>${escapeHtml(selectedPipeline.id)} · 当前：${escapeHtml(pipelineStageLabel(selectedPipeline.currentStage))}</p></div>${badge(selectedPipeline.status)}</div>
        <div class="panel-body pipeline-body">
          <div class="pipeline-stages">${state.pipeline.stages.map((stage, index) => {
            const stageState = selectedPipeline.stages?.[stage]?.status || "pending";
            return `<div class="pipeline-stage ${escapeHtml(stageState)}"><span>${index + 1}</span><div><strong>${escapeHtml(pipelineStageLabel(stage))}</strong><small>${escapeHtml(stageState)}</small></div></div>`;
          }).join("")}</div>
          ${selectedPipeline.requiredInput ? `<div class="callout"><i data-lucide="log-in"></i><div><strong>需要人工输入</strong><span>${escapeHtml(selectedPipeline.requiredInput)}</span></div></div>` : ""}
          <div class="action-strip">
            ${["waiting_input", "paused"].includes(selectedPipeline.status) ? `<button class="button primary" id="resumePipelineButton" type="button"><i data-lucide="file-input"></i>登记输入并排队</button>` : ""}
            ${selectedPipeline.status === "circuit_open" ? `<button class="button danger" id="recoverPipelineButton" type="button"><i data-lucide="shield-check"></i>人工确认恢复</button>` : ""}
          </div>
          <p class="pipeline-note">服务器可以长期保存阶段、租约、产物引用和熔断状态；没有网易会话或结果文件时不会继续执行，也不会绕过验证码、权限或付费限制。</p>
        </div>
      </section>` : ""}

      ${selected ? `<section class="panel">
        <div class="panel-head"><div><h3>${escapeHtml(selected.hsCode)} 运行面板</h3><p>${escapeHtml(selected.id)}</p></div><div>${badge(selected.safetyState)}</div></div>
        <div class="panel-body">
          <div class="budget-grid">
            ${budgetMeter("买家条目", counters.buyerEntries, budgets.buyerEntriesDaily, remaining(counters.buyerEntries, budgets.buyerEntriesDaily))}
            ${budgetMeter("公司搜索", counters.companySearches, null, null)}
            ${budgetMeter("新公司详情", counters.companyDetails, budgets.companyDetailsDaily, remaining(counters.companyDetails, budgets.companyDetailsDaily))}
            ${budgetMeter("联系人分页", counters.contactPages, budgets.contactPagesDaily, remaining(counters.contactPages, budgets.contactPagesDaily))}
            ${budgetMeter("原始联系人行", counters.rawContactRows, null, null)}
          </div>
          <form class="ops-action-form" id="opsActionForm">
            <div class="form-grid"><div class="field"><label for="opsSignal">页面/安全信号</label><select class="select" id="opsSignal"><option value="none">正常</option><option value="captcha">验证码</option><option value="frequent_operation">操作频繁</option><option value="permission">权限提示</option><option value="http_403">HTTP 403</option><option value="http_429">HTTP 429</option><option value="structure_error">结构异常</option><option value="duplicate_page">重复页</option><option value="page_stuck">页码不前进</option></select></div><div class="field"><label for="opsCount">本次计数</label><input class="input" id="opsCount" type="number" min="1" max="500" value="1" /></div></div>
            <div class="form-grid"><div class="field"><label for="checkpointCompany">检查点公司</label><input class="input" id="checkpointCompany" value="${escapeHtml(selected.checkpoint?.company || "")}" /></div><div class="field"><label for="checkpointPage">当前页码</label><input class="input" id="checkpointPage" type="number" min="0" value="${Number(selected.checkpoint?.page || 0)}" /></div></div>
            <div class="field"><label for="checkpointNote">检查点备注</label><input class="input" id="checkpointNote" value="${escapeHtml(selected.checkpoint?.note || "")}" placeholder="结果数已稳定、字段正常、无保护提示" /></div>
            <div class="action-strip">
              <button class="button" data-op-action="buyer_entry" type="button"><i data-lucide="building-2"></i>买家条目</button>
              <button class="button" data-op-action="company_search" type="button"><i data-lucide="search"></i>公司搜索</button>
              <button class="button" data-op-action="company_detail" type="button"><i data-lucide="panel-top-open"></i>公司详情</button>
              <button class="button" data-op-action="contact_page" type="button"><i data-lucide="book-open"></i>联系人分页</button>
              <button class="button" data-op-action="raw_contact_row" type="button"><i data-lucide="contact-round"></i>联系人行</button>
              <button class="button" data-op-action="checkpoint" type="button"><i data-lucide="save"></i>仅保存检查点</button>
              ${selected.safetyState === "CIRCUIT_OPEN" ? `<button class="button danger" id="recoverTaskButton" type="button"><i data-lucide="shield-check"></i>人工恢复</button>` : ""}
            </div>
          </form>
          <div class="callout"><i data-lucide="circle-stop"></i><div><strong>自动停止规则</strong><span>验证码、操作频繁、权限提示、403/429立即熔断；连续3次结构/分页异常熔断；任何动作超预算拒绝写入。</span></div></div>
        </div>
      </section>

      <section class="panel">
        <div class="panel-head"><h3>最近任务审计</h3><span class="badge neutral">显示 ${number(Math.min(selected.audit?.length || 0, 20))} / ${number(selected.audit?.length || 0)} 条</span></div>
        <div class="table-shell"><table><thead><tr><th>时间</th><th>动作</th><th>数量</th><th>安全信号</th><th>结果状态</th></tr></thead><tbody>${(selected.audit || []).slice(0, 20).map((item) => `<tr><td>${escapeHtml(shortDateTime(item.at))}</td><td>${escapeHtml(auditActionLabel(item))}</td><td>${escapeHtml(auditCountLabel(item))}</td><td>${escapeHtml(item.signal || "-")}</td><td>${badge(item.safetyState || "-")}</td></tr>`).join("") || `<tr><td colspan="5">暂无审计记录</td></tr>`}</tbody></table></div>
      </section>` : ""}

      <section class="split-layout ops-layout">
        <div class="panel"><div class="panel-head"><h3>永久抑制名单</h3><span class="badge blocked">不可自动删除</span></div><form class="panel-body editor" id="suppressionForm"><div class="field"><label for="suppressionEmail">邮箱</label><input class="input" id="suppressionEmail" type="email" required /></div><div class="form-grid"><div class="field"><label for="suppressionReason">原因</label><select class="select" id="suppressionReason"><option value="opted_out">退订</option><option value="complaint">投诉</option><option value="hard_bounce">硬退信</option><option value="do_not_contact">明确拒绝联系</option><option value="manual">人工抑制</option></select></div><div class="field"><label for="suppressionSource">证据来源</label><input class="input" id="suppressionSource" value="local-admin" required /></div></div><button class="button danger" type="submit"><i data-lucide="ban"></i>加入永久抑制</button></form></div>
        <div class="panel"><div class="panel-head"><h3>最近抑制记录</h3><span class="badge neutral">只显示哈希前缀</span></div><div class="table-shell"><table><thead><tr><th>指纹</th><th>域名</th><th>原因</th><th>日期</th></tr></thead><tbody>${state.suppressions.items.slice(0, 10).map((item) => `<tr><td><code>${escapeHtml(item.fingerprint)}</code></td><td>${escapeHtml(item.domain)}</td><td>${escapeHtml(item.reason)}</td><td>${shortDate(item.createdAt)}</td></tr>`).join("") || `<tr><td colspan="4">暂无抑制记录</td></tr>`}</tbody></table></div></div>
      </section>
    </div>`;
}

function budgetMeter(label, used, limit, remaining) {
  const ratio = limit ? Math.min((Number(used || 0) / Number(limit)) * 100, 100) : 0;
  return `<article class="budget-card"><span>${escapeHtml(label)}</span><strong>${number(used)}${limit ? ` / ${number(limit)}` : ""}</strong>${limit ? `<div class="progress-track"><div class="progress-fill ${ratio >= 100 ? "red" : ratio >= 75 ? "amber" : ""}" style="width:${ratio}%"></div></div><small>剩余 ${number(remaining)}</small>` : `<small>仅计数，不设独立上限</small>`}</article>`;
}

function renderEmailClaims() {
  return (state.options.emailClaims || []).map((claim) => `
    <label class="claim-option">
      <input type="checkbox" name="approvedClaim" value="${escapeHtml(claim.id)}" />
      <span><strong>${escapeHtml(claim.label)}</strong><small>只有已核实且允许对外使用时才勾选</small></span>
    </label>`).join("");
}

function renderEmailAssets() {
  return (state.options.emailAssets || []).map((asset) => `
    <label class="asset-option">
      <input type="checkbox" name="emailAsset" value="${escapeHtml(asset.id)}" />
      <img src="${escapeHtml(asset.url)}" alt="${escapeHtml(asset.label)}" loading="lazy" />
      <span>${escapeHtml(asset.label)}</span>
    </label>`).join("");
}

function selectedValues(name) {
  return [...document.querySelectorAll(`input[name="${name}"]:checked`)].map((input) => input.value);
}

function syncScenarioControls() {
  const select = document.getElementById("draftScenario");
  if (!select) return;
  const scenario = (state.options.emailScenarios || []).find((item) => item.id === select.value);
  if (!scenario) return;
  const note = document.getElementById("scenarioNote");
  if (note) note.textContent = `${scenario.name}建议 ${scenario.wordRange[0]}-${scenario.wordRange[1]} 词，最多 ${scenario.maxAssets} 张配图。`;
  const selected = [...document.querySelectorAll('input[name="emailAsset"]:checked')];
  selected.slice(scenario.maxAssets).forEach((input) => { input.checked = false; });
  document.querySelectorAll('input[name="emailAsset"]').forEach((input) => {
    input.disabled = !input.checked && selectedValues("emailAsset").length >= scenario.maxAssets;
  });
}

function renderCampaigns() {
  const campaigns = state.campaigns;
  const aiRuntime = aiRuntimeState();
  const aiReady = aiRuntime.ready;
  const deliveryReady = Boolean(state.health?.delivery?.enabled && state.health?.delivery?.smtpConfigured);
  return `
    <div class="view-stack">
      <div class="callout"><i data-lucide="${deliveryReady ? "shield-check" : "lock-keyhole"}"></i><div><strong>AI：${escapeHtml(aiRuntime.label)}；SMTP发送${deliveryReady ? "已启用" : "保持锁定"}</strong><span>模型只生成草稿；保存、预览、审核和发送分开执行。发送批次上限 ${number(state.health?.delivery?.batchLimit || 5)} 封，间隔 ${number(state.health?.delivery?.delayMs || 2000)} 毫秒。</span></div></div>
      <section class="campaign-layout">
        <div class="panel">
          <div class="panel-head"><h3>活动草稿与审核队列</h3><span class="badge neutral">${campaigns.length} 个活动</span></div>
          <div class="campaign-list">
            ${campaigns.length ? campaigns.map((item) => `
              <article class="campaign-row">
                <div><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(item.subject || "未填写主题")} · 更新 ${shortDate(item.updatedAt)}</small></div>
                <div><strong>${number(item.estimatedRecipients)}</strong><small>${number(item.sendableRecipients)} 个可发送</small></div>
                <div>${badge(item.status)}</div>
                <div class="campaign-actions">
                  <button class="icon-button" data-preview-campaign="${item.id}" title="生成预览" aria-label="生成预览"><i data-lucide="eye"></i></button>
                  ${item.status === "draft" ? `<button class="icon-button" data-review-campaign="${item.id}" title="提交审核" aria-label="提交审核"><i data-lucide="clipboard-check"></i></button>` : ""}
                  ${item.status === "review" ? `<button class="icon-button" data-approve-campaign="${item.id}" title="批准活动" aria-label="批准活动"><i data-lucide="shield-check"></i></button>` : ""}
                  ${item.status === "review" ? `<button class="icon-button" data-schedule-campaign="${item.id}" title="模拟排期" aria-label="模拟排期"><i data-lucide="calendar-clock"></i></button>` : ""}
                  ${deliveryReady && ["approved", "partially_sent"].includes(item.status) ? `<button class="icon-button" data-send-campaign="${item.id}" title="发送下一安全批次" aria-label="发送下一安全批次"><i data-lucide="send"></i></button>` : ""}
                </div>
              </article>`).join("") : emptyState("mail-open", "暂无活动", "右侧保存第一个本地邮件草稿。")}
          </div>
        </div>

        <div class="panel">
          <div class="panel-head"><h3>新建邮件草稿</h3>${badge("draft")}</div>
          <form class="panel-body editor" id="campaignForm">
            <section class="ai-builder" aria-labelledby="aiBuilderTitle">
              <div class="ai-builder-head"><div><h4 id="aiBuilderTitle">场景化 GPT-5.6 邮件起草</h4><p>HSCode只用于内部产品匹配；正文不暴露海关数据来源。所有高风险卖点和配图均需人工批准。</p></div>${badge(aiRuntime.status)}</div>
              <div class="form-grid">
                <div class="field"><label for="draftScenario">邮件场景</label><select class="select" id="draftScenario">${(state.options.emailScenarios || []).map((item) => `<option value="${escapeHtml(item.id)}">${escapeHtml(item.name)}</option>`).join("")}</select></div>
                <div class="field"><label for="hsCode">HSCode（仅内部匹配）</label><input class="input" id="hsCode" value="4903000" required /></div>
              </div>
              <div class="scenario-note" id="scenarioNote">首次开发信建议 80-130 词，默认不带图，最多 1 张。</div>
              <div class="form-grid">
                <div class="field"><label for="buyerCompany">买家公司</label><input class="input" id="buyerCompany" value="{{company}}" /></div>
                <div class="field"><label for="contactName">联系人</label><input class="input" id="contactName" value="{{first_name}}" /></div>
              </div>
              <div class="field"><label for="contactRole">联系人岗位</label><input class="input" id="contactRole" placeholder="e.g. Logistics Manager / Procurement Director" /></div>
              <div class="field"><label for="productFocus">HSCode对应产品方向</label><textarea class="textarea compact" id="productFocus" required>Children's picture, drawing, coloring and activity books; hardcover or paperback formats and related finishing.</textarea></div>
              <div class="field"><label for="tradeContent">已核实的采购商业务证据</label><textarea class="textarea compact" id="tradeContent" required>The buyer publishes or sources children's activity and coloring books.</textarea></div>
              <div class="field"><label for="companyBusiness">我方业务与可提供能力</label><textarea class="textarea compact" id="companyBusiness" required>Dakings provides book printing, binding, packaging, and post-press finishing services in China.</textarea></div>

              <details class="brief-details">
                <summary>展会/拜访资料（仅展会场景必填）</summary>
                <div class="event-fields">
                  <div class="form-grid">
                    <div class="field"><label for="eventName">展会名称</label><input class="input" id="eventName" /></div>
                    <div class="field"><label for="eventDates">日期</label><input class="input" id="eventDates" placeholder="June 23-25, 2026" /></div>
                  </div>
                  <div class="form-grid">
                    <div class="field"><label for="eventBooth">展位号</label><input class="input" id="eventBooth" /></div>
                    <div class="field"><label for="meetingLocation">备选约见地点</label><input class="input" id="meetingLocation" /></div>
                  </div>
                  <div class="field"><label for="eventAddress">展馆详细地址</label><input class="input" id="eventAddress" /></div>
                </div>
              </details>

              <details class="brief-details">
                <summary>受控卖点批准（默认全不勾选）</summary>
                <div class="claim-grid">${renderEmailClaims()}</div>
              </details>

              <div class="field">
                <label>可选配图（首次触达最多1张，展会场景最多2张）</label>
                <div class="asset-grid">${renderEmailAssets()}</div>
              </div>
              <label class="check-row"><input id="assetRightsConfirmed" type="checkbox" />已确认所选图片属于我方且允许对该收件人使用</label>
              <div class="form-grid">
                <div class="field"><label for="senderName">发件人</label><input class="input" id="senderName" value="Emma" /></div>
                <div class="field"><label for="senderCompany">发件公司</label><input class="input" id="senderCompany" value="Dakings Printing" /></div>
              </div>
              <div class="form-grid">
                <div class="field"><label for="draftTone">语气</label><select class="select" id="draftTone"><option value="concise and professional">简洁专业</option><option value="warm and consultative">温和顾问式</option><option value="direct and practical">直接务实</option></select></div>
                <div class="field"><label>生成约束</label><div class="static-field">单一CTA · 不写虚假熟络 · 不暴露数据来源</div></div>
              </div>
              <div class="ai-builder-actions"><button class="button primary" id="aiDraftButton" type="button" ${aiReady ? "" : "disabled"}><i data-lucide="wand-sparkles"></i>生成主题与正文</button><span id="aiDraftStatus">${escapeHtml(aiRuntime.label)}</span></div>
            </section>
            <div class="field"><label for="campaignName">活动名称</label><input class="input" id="campaignName" name="name" value="Mexico publishing buyers - pilot" required /></div>
            <div class="field"><label for="campaignSubject">邮件主题</label><input class="input" id="campaignSubject" name="subject" value="Printing support for {{company}}" required /></div>
            <div class="variable-bar">${state.options.variables.map((item) => `<button class="token" type="button" data-token="${escapeHtml(item)}">${escapeHtml(item)}</button>`).join("")}</div>
            <div class="field"><label for="campaignBody">正文</label><textarea class="textarea" id="campaignBody" name="body" required>Hi {{first_name}},

I'm Emma from Dakings Printing in Guangzhou. {{company}}'s work with children's picture, activity or coloring books appears relevant to our book printing, binding, packaging and post-press finishing capabilities.

For an upcoming title, we can quote against the exact trim size, page count, paper, binding, finishing, pack-out and delivery requirements. This gives your team a clear specification-based comparison without a long back-and-forth.

Would you be open to sharing one current specification or RFQ for review? If another colleague manages print sourcing, I would appreciate an introduction.

Best regards,
Emma
Dakings Printing</textarea></div>
            <div class="form-grid">
              <div class="field"><label for="campaignCountry">目标国家</label><select class="select" id="campaignCountry"><option value="">全部国家</option><option value="Mexico" selected>Mexico</option><option value="United States">United States</option><option value="Bolivia">Bolivia</option><option value="Brazil">Brazil</option><option value="Colombia">Colombia</option></select></div>
              <div class="field"><label for="campaignPriority">联系人角色</label><select class="select" id="campaignPriority"><option value="">全部角色</option>${state.options.priorities.map((item) => `<option value="${escapeHtml(item)}">${escapeHtml(item)}</option>`).join("")}</select></div>
            </div>
            <div class="check-grid">
              <label class="check-row"><input id="highConfidenceOnly" type="checkbox" checked />排除低置信匹配</label>
              <label class="check-row"><input id="suppressionChecked" type="checkbox" />已检查抑制名单</label>
              <label class="check-row"><input id="unsubscribeConfigured" type="checkbox" />已配置退订</label>
              <label class="check-row"><input id="senderDomainVerified" type="checkbox" />发件域名已验证</label>
              <label class="check-row"><input id="physicalAddressConfigured" type="checkbox" />已配置实体地址</label>
            </div>
            <button class="button primary" type="submit"><i data-lucide="save"></i>保存草稿</button>
          </form>
        </div>
      </section>
      ${renderCampaignPreview()}
    </div>`;
}

function renderCampaignPreview() {
  const preview = state.campaignPreview;
  if (!preview) return "";
  const errors = preview.contentErrors || [];
  const assets = preview.assets || [];
  return `<section class="panel"><div class="panel-head"><h3>个性化预览</h3><span class="badge neutral">预计 ${number(preview.estimatedRecipients)} 个候选邮箱</span></div><div class="panel-body preview-stack"><div class="callout"><i data-lucide="triangle-alert"></i><div><strong>预览不代表可发送</strong><span>${escapeHtml(preview.warning)}</span></div></div>${errors.length ? `<div class="content-errors"><strong>内容门槛未通过</strong><ul>${errors.map((error) => `<li>${escapeHtml(error)}</li>`).join("")}</ul></div>` : `<div class="content-pass"><i data-lucide="circle-check"></i><span>内容、字数、声明和配图门槛已通过</span></div>`}${assets.length ? `<div class="preview-assets">${assets.map((asset) => `<figure><img src="${escapeHtml(asset.url)}" alt="${escapeHtml(asset.label)}" /><figcaption>${escapeHtml(asset.label)}</figcaption></figure>`).join("")}</div>` : ""}<div class="preview-list">${preview.items.map((item) => `<article class="preview-item"><div class="preview-meta"><span>${escapeHtml(item.recipient.name || "公共邮箱")} · ${escapeHtml(item.recipient.company)}</span><span>${escapeHtml(item.recipient.email)} · ${number(item.wordCount)} words</span></div><div class="preview-subject">${escapeHtml(item.subject)}</div><div class="preview-body">${escapeHtml(item.body)}</div></article>`).join("")}</div></div></section>`;
}

function renderSettingsLegacy() {
  const aiRuntime = aiRuntimeState();
  const aiReady = aiRuntime.ready;
  const smtpReady = Boolean(state.health?.delivery?.smtpConfigured);
  const sendingEnabled = Boolean(state.health?.delivery?.enabled && smtpReady);
  return `
    <div class="view-stack">
      <div class="section-header"><div><h2>当前系统边界</h2><p>AI只生成草稿；真实发送由独立的SMTP开关、合规检查和批次确认控制。</p></div>${badge(sendingEnabled ? "partial" : "blocked")}</div>
      <section class="guardrail-grid">
        ${guardrail("database", "本地数据源", "读取现有采集JSON，不读取浏览器Cookie、LocalStorage或账号凭据。")}
        ${guardrail("shield-check", "只读采集", "正常页面、分页和公开字段；不绕过登录、付费、验证码或遮罩。")}
        ${guardrail(sendingEnabled ? "send" : "mail-x", sendingEnabled ? "受控发送已开启" : "真实发送关闭", sendingEnabled ? `每批最多${state.health.delivery.batchLimit}封，间隔${state.health.delivery.delayMs}毫秒，仍需逐批确认。` : "SMTP配置或EMAIL_SENDING_ENABLED尚未就绪。")}
        ${guardrail("user-check", "人工审核", "未来发送前必须确认实体、职位、邮箱有效性和退订状态。")}
        ${guardrail("list-x", "抑制名单", "退订、invalid、低置信和重复邮箱必须从收件人快照排除。")}
        ${guardrail("file-clock", "审计与归档", "任务动作、预算拒绝和恢复均可见并可导出；原始采集结果不覆盖。")}
      </section>
      <section class="panel"><div class="panel-head"><h3>功能开关</h3></div><div class="table-shell"><table><thead><tr><th>能力</th><th>状态</th><th>说明</th></tr></thead><tbody>
        <tr><td>海关与买家数据读取</td><td>${badge("complete")}</td><td>139家买家和前20联系人已连接</td></tr>
        <tr><td>联系人筛选与去重</td><td>${badge("complete")}</td><td>公司、邮箱、电话和LinkedIn分列</td></tr>
        <tr><td>邮箱格式与域名/MX检查</td><td>${badge("complete")}</td><td>使用本地规则和DNS，已保存 ${number(state.contactQuality.storedRecords)} 条状态；不声称可投递</td></tr>
        <tr><td>邮箱可投递/在职验证</td><td>${badge("blocked")}</td><td>deliverable 仍需人工证据或后续获准验证服务</td></tr>
        <tr><td>永久抑制名单</td><td>${badge("complete")}</td><td>${number(state.suppressions.count)} 条本地哈希记录会从活动收件人中自动排除</td></tr>
        <tr><td>HSCode预算与检查点</td><td>${badge("complete")}</td><td>${number(state.operationTasks.length)} 个本地任务；支持预算拒绝、保护信号熔断和人工恢复</td></tr>
        <tr><td>本地控制备份</td><td>${badge("complete")}</td><td>导出验证、抑制、任务审计和活动草稿；不含密钥、Cookie或原始联系人数据，并附SHA-256摘要</td></tr>
        <tr><td>GPT-5.6邮件起草</td><td>${badge(aiReady ? "complete" : "blocked")}</td><td>${aiReady ? `Responses API已配置，模型 ${escapeHtml(state.health.ai.model)}` : "OPENAI_API_KEY未配置"}</td></tr>
        <tr><td>邮件草稿与预览</td><td>${badge("complete")}</td><td>AI输出先进入人工可编辑草稿，不会自动发送</td></tr>
        <tr><td>SMTP连接</td><td>${badge(smtpReady ? "complete" : "blocked")}</td><td>${smtpReady ? "SMTP凭据完整，前端不可读取" : "需要SMTP_HOST、SMTP_USER、SMTP_PASS和SMTP_FROM"}</td></tr>
        <tr><td>SMTP真实发送</td><td>${badge(sendingEnabled ? "partial" : "blocked")}</td><td>${sendingEnabled ? "逐批确认、限量、限速并写入本地审计" : "默认关闭；须显式设置EMAIL_SENDING_ENABLED=true"}</td></tr>
      </tbody></table></div></section>
    </div>`;
}

function renderSettings() {
  const aiRuntime = aiRuntimeState();
  const smtpReady = Boolean(state.health?.delivery?.smtpConfigured);
  const sendingEnabled = Boolean(state.health?.delivery?.enabled && smtpReady);
  const deliverySummary = sendingEnabled
    ? `已配置；每批最多 ${number(state.health.delivery.batchLimit)} 封，间隔 ${number(state.health.delivery.delayMs)} ms，仍需逐批确认`
    : "已锁定；未配置 SMTP 或 EMAIL_SENDING_ENABLED 未显式开启";
  return `
    <div class="view-stack settings-view">
      <div class="section-header"><div><h2>系统边界与外部依赖</h2><p>本页把能在本地完成的工作、需要业务确认的事项，以及必须购买或配置的能力分开显示。</p></div>${badge(sendingEnabled ? "partial" : "blocked")}</div>
      <section class="boundary-callout"><div class="boundary-callout-icon"><i data-lucide="shield-check"></i></div><div><strong>当前安全策略</strong><p>网易页面只使用你提供的网易外贸账号和正常页面流程；不会绕过登录、验证码、付费墙或平台限制。AI 只生成草稿，邮箱格式/域名检查也不等于可投递。</p></div><span class="boundary-lock"><i data-lucide="lock-keyhole"></i>真实发送 ${sendingEnabled ? "受控开启" : "已锁定"}</span></section>
      <section class="dependency-toolbar"><div><h3>外部依赖清单</h3><p>完成这些项目后，系统才会把对应能力从“待确认/受限”推进到可验收状态。</p></div><div class="section-actions"><button class="button small" id="copyDependencyChecklist" type="button"><i data-lucide="clipboard-copy"></i>复制配置字段</button><button class="button small" id="downloadDependencyChecklist" type="button"><i data-lucide="download"></i>下载清单</button></div></section>
      <section class="account-prereq"><div class="account-prereq-icon"><i data-lucide="log-in"></i></div><div><strong>网易外贸账号运行前置</strong><p>由你提供账号并在网易外贸页面完成现场登录；本项目不把网易使用权计入购买项，也不会代替你处理登录验证码。</p></div><span class="badge neutral">不购买</span></section>
      <section class="dependency-grid">
        ${dependencyCard("local", "本地已完成", "可立即使用", "database", ["买家与联系人本地数据读取", "去重、抑制名单、DNS 域名检查", "HSCode 九阶段队列、租约恢复、熔断和检查点", "AI 草稿、人工审核与幂等发件箱"], "不需要购买；数据只写入服务器运行目录，真实发送仍保持关闭。")}
        ${dependencyCard("confirm", "用户确认即可推进", "待你提供证据", "user-round-check", ["业务事实与卖点白名单", "每批发送的收件人、主题和退订策略", "配图的对外使用权", "联系人职位与采购证据的人工复核"], "需要业务负责人确认，不能用 AI 推测替代。")}
        ${dependencyCard("external", "必须购买 / 配置", "外部服务门槛", "key-round", ["邮箱在职/可投递验证服务，或人工证据", "发件域名、SMTP/DMARC/SPF/DKIM 配置", "退订、退信、合规记录与 CRM 写入权限"], "网易外贸账号由你提供并现场登录；本清单不把网易使用权列为购买项。")}
      </section>
      <section class="panel dependency-table-panel"><div class="panel-head"><div><h3>能力验收矩阵</h3><span class="panel-caption">状态是当前本地检测结果，不代表外部服务已经购买或联系人已经验证。</span></div></div><div class="table-shell"><table><thead><tr><th>能力</th><th>当前状态</th><th>为什么受限</th><th>完成证据</th></tr></thead><tbody>
        <tr><td>网易公开页面搜索</td><td>${badge("partial")}</td><td>可使用你提供的网易外贸账号和正常页面；尚未形成无人值守执行器</td><td>搜索结果文件、任务 HSCode、页面检查点与连续运行记录</td></tr>
        <tr><td>HSCode持久流水线</td><td>${badge("complete")}</td><td>${number(state.pipeline.jobs.length)} 个任务；缺少网易输入时自动停在waiting_input</td><td>阶段状态、租约、产物引用、熔断与恢复审计</td></tr>
        <tr><td>联系人本地质量检查</td><td>${badge("complete")}</td><td>syntax_valid / domain_valid 不证明邮箱可投递</td><td>检查记录、DNS 结果、抑制名单命中记录</td></tr>
        <tr><td>邮箱在职 / 可投递验证</td><td>${badge("blocked")}</td><td>需要第三方服务订阅或人工证据</td><td>服务报告或人工验证凭证</td></tr>
        <tr><td>GPT-5.6 草稿</td><td>${badge(aiRuntime.status)}</td><td>${escapeHtml(aiRuntime.label)}；输出仍需审核</td><td>最近请求时间、成功时间、错误与人工审核记录</td></tr>
        <tr><td>邮件幂等发件箱</td><td>${badge("complete")}</td><td>发送前落盘；accepted/sending/uncertain 禁止自动重试</td><td>${number(state.outbox.counts?.accepted || 0)} 已接受，${number(state.outbox.counts?.uncertain || 0)} 待人工裁决</td></tr>
        <tr><td>SMTP 连接与真实发送</td><td>${badge(sendingEnabled ? "partial" : "blocked")}</td><td>${escapeHtml(deliverySummary)}</td><td>SMTP 连通性、退信/退订日志、逐批批准记录</td></tr>
        <tr><td>本地控制备份与恢复</td><td>${badge("complete")}</td><td>仅安全合并，禁止破坏性覆盖</td><td>SHA-256 摘要、回滚快照、合并审计</td></tr>
      </tbody></table></div></section>
      <section class="guardrail-grid">
        ${guardrail("database", "本地数据源", "读取现有采集 JSON，不读取浏览器 Cookie、LocalStorage 或账号凭据。")}
        ${guardrail("shield-check", "网易账号正常操作", "使用你提供的网易外贸账号和正常页面，不绕过登录、付费、验证码或平台限制。")}
        ${guardrail(sendingEnabled ? "send" : "mail-x", sendingEnabled ? "受控发送已开启" : "真实发送已关闭", deliverySummary)}
        ${guardrail("user-check", "人工复核", "发送前确认实体、职位、邮箱状态、业务事实和退订状态。")}
        ${guardrail("list-x", "永久抑制", `退订、invalid、低置信和重复邮箱从活动收件人中自动排除；当前 ${number(state.suppressions.count)} 条。`)}
        ${guardrail("file-clock", "审计与归档", `任务、流水线、发件箱和恢复状态均持久化；当前 ${number(state.operationTasks.length)} 个任务、${number(state.pipeline.jobs.length)} 条流水线。`)}
      </section>
    </div>`;
}

function dependencyCard(kind, title, status, icon, items, note) {
  return `<article class="dependency-card ${kind}"><div class="dependency-card-head"><div class="dependency-icon"><i data-lucide="${icon}"></i></div><div><h3>${escapeHtml(title)}</h3><span>${escapeHtml(status)}</span></div></div><ul>${items.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul><p class="dependency-note">${escapeHtml(note)}</p></article>`;
}

const dependencyChecklistText = `外贸自动化拓客系统：外部购买 / 配置清单

网易账号（不计入购买项）：使用你提供的网易外贸账号现场登录，保持正常页面会话。
1. 邮箱验证：在职/可投递验证服务订阅，或每个邮箱的人工验证证据。
2. 发件基础设施：发件域名、SMTP_HOST、SMTP_PORT、SMTP_USER、SMTP_PASS、SMTP_FROM。
3. 域名认证：SPF、DKIM、DMARC，以及退信处理邮箱。
4. 合规配置：退订 URL、发件方实体地址、抑制名单维护和 CRM 写入权限。

无需购买、但必须由业务负责人确认：业务事实、卖点白名单、配图对外使用证明，以及每批收件人和退订策略。

验收标准：服务回执/人工证据可追溯，逐批审批与退订记录可导出；管理员权限不能替代外部订阅、域名配置或业务确认。`;

async function copyDependencyChecklist() {
  try {
    await navigator.clipboard.writeText(dependencyChecklistText);
    toast("配置字段清单已复制");
  } catch {
    toast("浏览器未允许复制，请使用下载清单", "error");
  }
}

function downloadDependencyChecklist() {
  const blob = new Blob([`${dependencyChecklistText}\n`], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "外贸自动化拓客系统-外部购买授权清单.txt";
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  toast("外部购买 / 授权清单已下载");
}

function guardrail(icon, heading, body) {
  return `<article class="guardrail"><div class="guardrail-icon"><i data-lucide="${icon}"></i></div><h3>${escapeHtml(heading)}</h3><p>${escapeHtml(body)}</p></article>`;
}

function render() {
  const meta = viewMeta[state.view];
  eyebrow.textContent = meta[0];
  title.textContent = meta[1];
  document.querySelectorAll(".nav-item").forEach((item) => item.classList.toggle("active", item.dataset.view === state.view));
  const renderer = {
    overview: renderOverview,
    workflow: renderWorkflow,
    buyers: renderBuyers,
    contacts: renderContacts,
    operations: renderOperations,
    campaigns: renderCampaigns,
    settings: renderSettings,
  }[state.view];
  main.innerHTML = renderer();
  bindViewEvents();
  refreshIcons();
}

async function loadBuyers() {
  state.buyers = await api(`/api/buyers?${queryString(state.buyerFilters)}`);
}

async function loadContacts() {
  state.contacts = await api(`/api/contacts?${queryString(state.contactFilters)}`);
}

async function loadCampaigns() {
  state.campaigns = await api("/api/campaigns");
}

async function loadLocalControls() {
  const [contactQuality, suppressions, operations, pipeline, outbox] = await Promise.all([
    api("/api/contact-quality"),
    api("/api/suppressions"),
    api("/api/ops/tasks"),
    api("/api/pipeline"),
    api("/api/outbox"),
  ]);
  state.contactQuality = contactQuality;
  state.suppressions = suppressions;
  state.operationTasks = operations.items;
  state.pipeline = pipeline;
  state.outbox = outbox;
  if (!state.operationTasks.some((item) => item.id === state.selectedTaskId)) {
    state.selectedTaskId = state.operationTasks[0]?.id || null;
  }
}

async function validateContactEmail(email) {
  try {
    const result = await api("/api/contact-quality/validate", {
      method: "POST",
      body: JSON.stringify({ email, mode: "domain" }),
    });
    await Promise.all([loadContacts(), loadLocalControls()]);
    render();
    toast(`本地检查完成：${result.results[0]?.status || "unknown"}`);
  } catch (error) {
    toast(error.message, "error");
  }
}

async function validateCurrentContactPage() {
  const button = document.getElementById("validatePageButton");
  const contactIds = state.contacts.items
    .filter((item) => item.email && !item.suppressed)
    .map((item) => item.id)
    .slice(0, 25);
  if (!contactIds.length) return;
  if (button) {
    button.disabled = true;
    button.textContent = "正在执行本地检查";
  }
  try {
    const result = await api("/api/contact-quality/validate", {
      method: "POST",
      body: JSON.stringify({ contactIds, mode: "domain" }),
    });
    await Promise.all([loadContacts(), loadLocalControls()]);
    render();
    toast(`已检查 ${number(result.processed)} 个邮箱，复用为 ${number(result.uniqueDomains)} 个域名查询`);
  } catch (error) {
    toast(error.message, "error");
    render();
  }
}

function downloadJson(filename, payload) {
  const blob = new Blob([`${JSON.stringify(payload, null, 2)}\n`], { type: "application/json;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function exportLocalBackup() {
  try {
    const backup = await api("/api/local-backup");
    const stamp = String(backup.exportedAt || new Date().toISOString()).slice(0, 10);
    downloadJson(`dakings-local-control-backup-${stamp}.json`, backup);
    toast("本地控制备份已导出并附带SHA-256摘要");
  } catch (error) {
    toast(error.message, "error");
  }
}

function validateLocalBackupFile() {
  const input = document.createElement("input");
  input.type = "file";
  input.accept = "application/json,.json";
  input.addEventListener("change", async () => {
    const file = input.files?.[0];
    if (!file) return;
    try {
      const backup = JSON.parse(await file.text());
      const result = await api("/api/local-backup/validate", {
        method: "POST",
        body: JSON.stringify(backup),
      });
      const counts = result.counts || {};
      toast(`备份有效：验证 ${number(counts.validationRecords)}、任务 ${number(counts.operationTasks)}、流水线 ${number(counts.pipelineJobs)}、发件箱 ${number(counts.outboxEntries)}、草稿 ${number(counts.campaigns)}`);
    } catch (error) {
      const message = error instanceof SyntaxError ? "所选文件不是有效的JSON备份" : error.message;
      toast(message, "error");
    }
  }, { once: true });
  input.click();
}

function mergeLocalBackupFile() {
  const input = document.createElement("input");
  input.type = "file";
  input.accept = "application/json,.json";
  input.addEventListener("change", async () => {
    const file = input.files?.[0];
    if (!file) return;
    try {
      const backup = JSON.parse(await file.text());
      const preview = await api("/api/local-backup/preview", {
        method: "POST",
        body: JSON.stringify(backup),
      });
      const added = preview.added || {};
      const summary = `将新增：验证 ${number(added.validationRecords)}、抑制 ${number(added.suppressions)}、任务 ${number(added.operationTasks)}、流水线 ${number(added.pipelineJobs)}、发件箱 ${number(added.outboxEntries)}、草稿 ${number(added.campaigns)}。\n现有同标识记录全部保留，不执行覆盖或删除。\n\n请输入确认短语：\n${preview.confirmation}`;
      const confirmation = window.prompt(summary);
      if (confirmation !== preview.confirmation) {
        toast("安全合并已取消", "error");
        return;
      }
      const result = await api("/api/local-backup/merge", {
        method: "POST",
        body: JSON.stringify({ backup, confirm: confirmation }),
      });
      await Promise.all([loadContacts(), loadLocalControls(), loadCampaigns()]);
      render();
      const totalAdded = Object.values(result.added || {}).reduce((sum, value) => sum + Number(value || 0), 0);
      toast(`安全合并完成，新增 ${number(totalAdded)} 条；已生成回滚快照 ${result.rollbackFile}`);
    } catch (error) {
      const message = error instanceof SyntaxError ? "所选文件不是有效的JSON备份" : error.message;
      toast(message, "error");
    }
  }, { once: true });
  input.click();
}

function exportSelectedTask() {
  const task = state.operationTasks.find((item) => item.id === state.selectedTaskId);
  if (!task) return;
  downloadJson(`hscode-${task.hsCode}-${task.id}.json`, {
    schemaVersion: 1,
    exportedAt: new Date().toISOString(),
    task,
  });
  toast(`HSCode ${task.hsCode} 任务已导出`);
}

async function suppressEmail(email, reason = "manual", source = "local-admin", skipConfirm = false) {
  if (!skipConfirm && !window.confirm(`确认把 ${email} 加入永久抑制名单？此界面不提供自动删除。`)) return;
  try {
    await api("/api/suppressions", {
      method: "POST",
      body: JSON.stringify({ email, reason, source }),
    });
    await Promise.all([loadContacts(), loadLocalControls(), loadCampaigns()]);
    render();
    toast("已加入永久抑制名单");
  } catch (error) {
    toast(error.message, "error");
  }
}

async function addSuppression(event) {
  event.preventDefault();
  const email = document.getElementById("suppressionEmail").value.trim();
  const reason = document.getElementById("suppressionReason").value;
  const source = document.getElementById("suppressionSource").value.trim();
  if (!window.confirm(`确认永久抑制 ${email}？`)) return;
  await suppressEmail(email, reason, source, true);
}

async function createOpsTask(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const payload = {
    hsCode: form.get("hsCode"),
    direction: form.get("direction"),
    countries: String(form.get("countries") || "").split(",").map((item) => item.trim()).filter(Boolean),
    budgets: {
      buyerEntriesDaily: Number(form.get("buyerBudget")),
      companyDetailsDaily: Number(form.get("detailBudget")),
      contactPagesDaily: Number(form.get("contactPageBudget")),
    },
  };
  try {
    const task = await api("/api/ops/tasks", { method: "POST", body: JSON.stringify(payload) });
    state.selectedTaskId = task.id;
    await loadLocalControls();
    render();
    toast(`HSCode ${task.hsCode} 任务已冻结`);
  } catch (error) {
    toast(error.message, "error");
  }
}

async function recordOpsAction(type) {
  const task = state.operationTasks.find((item) => item.id === state.selectedTaskId);
  if (!task) return;
  const payload = {
    type,
    count: Number(document.getElementById("opsCount")?.value || 1),
    signal: document.getElementById("opsSignal")?.value || "none",
    checkpoint: {
      company: document.getElementById("checkpointCompany")?.value || "",
      page: Number(document.getElementById("checkpointPage")?.value || 0),
      note: document.getElementById("checkpointNote")?.value || "",
    },
  };
  try {
    await api(`/api/ops/tasks/${task.id}/actions`, { method: "POST", body: JSON.stringify(payload) });
    toast(payload.signal === "none" ? "动作与检查点已记录" : "安全信号已记录，状态已自动调整");
  } catch (error) {
    toast(error.message, "error");
  } finally {
    await loadLocalControls();
    render();
  }
}

async function recoverOpsTask() {
  const task = state.operationTasks.find((item) => item.id === state.selectedTaskId);
  if (!task) return;
  const phrase = `RECOVER ${task.id}`;
  const confirmation = window.prompt(`人工确认页面和账号已经恢复后输入：\n${phrase}`);
  if (confirmation !== phrase) return toast("恢复已取消", "error");
  try {
    await api(`/api/ops/tasks/${task.id}/recover`, { method: "POST", body: JSON.stringify({ confirm: phrase }) });
    await loadLocalControls();
    render();
    toast("任务已进入人工恢复金丝雀档");
  } catch (error) {
    toast(error.message, "error");
  }
}

async function resumePipelineJob() {
  const task = state.operationTasks.find((item) => item.id === state.selectedTaskId);
  const job = state.pipeline.jobs.find((item) => item.operationTaskId === task?.id);
  if (!job) return;
  const reference = window.prompt("请输入网易正常页面结果或已导入文件的可追溯引用：");
  if (!reference?.trim()) return;
  try {
    await api(`/api/pipeline/jobs/${job.id}/resume`, {
      method: "POST",
      body: JSON.stringify({ inputReference: reference.trim() }),
    });
    await loadLocalControls();
    render();
    toast("输入引用已登记，流水线已进入可领取队列");
  } catch (error) {
    toast(error.message, "error");
  }
}

async function recoverPipelineJob() {
  const task = state.operationTasks.find((item) => item.id === state.selectedTaskId);
  const job = state.pipeline.jobs.find((item) => item.operationTaskId === task?.id);
  if (!job) return;
  const phrase = `RECOVER PIPELINE ${job.id}`;
  const confirmation = window.prompt(`确认保护提示已解除后输入：\n${phrase}`);
  if (confirmation !== phrase) return toast("流水线恢复已取消", "error");
  try {
    await api(`/api/pipeline/jobs/${job.id}/recover`, { method: "POST", body: JSON.stringify({ confirm: phrase }) });
    await loadLocalControls();
    render();
    toast("熔断已人工确认；任务保持暂停，需重新登记输入后再运行");
  } catch (error) {
    toast(error.message, "error");
  }
}

function bindViewEvents() {
  document.querySelectorAll("[data-jump]").forEach((button) => button.addEventListener("click", () => switchView(button.dataset.jump)));

  const buyerForm = document.getElementById("buyerFilterForm");
  if (buyerForm) buyerForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = new FormData(buyerForm);
    state.buyerFilters = { ...state.buyerFilters, q: form.get("q"), country: form.get("country"), confidence: form.get("confidence"), status: form.get("status"), page: 1 };
    await loadBuyers(); render();
  });

  const contactForm = document.getElementById("contactFilterForm");
  if (contactForm) contactForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = new FormData(contactForm);
    state.contactFilters = { ...state.contactFilters, q: form.get("q"), buyer: form.get("buyer"), priority: form.get("priority"), confidence: form.get("confidence"), validation: form.get("validation"), page: 1 };
    await loadContacts(); render();
  });

  document.getElementById("emailOnlyToggle")?.addEventListener("change", async (event) => {
    state.contactFilters.emailOnly = event.target.checked;
    state.contactFilters.page = 1;
    await loadContacts(); render();
  });

  document.querySelectorAll("[data-validate-email]").forEach((button) => button.addEventListener("click", () => validateContactEmail(button.dataset.validateEmail)));
  document.getElementById("validatePageButton")?.addEventListener("click", validateCurrentContactPage);
  document.querySelectorAll("[data-suppress-email]").forEach((button) => button.addEventListener("click", () => suppressEmail(button.dataset.suppressEmail, "manual", "contact-workbench")));
  document.getElementById("validateBackupButton")?.addEventListener("click", validateLocalBackupFile);
  document.getElementById("mergeBackupButton")?.addEventListener("click", mergeLocalBackupFile);
  document.getElementById("exportBackupButton")?.addEventListener("click", exportLocalBackup);
  document.getElementById("copyDependencyChecklist")?.addEventListener("click", copyDependencyChecklist);
  document.getElementById("downloadDependencyChecklist")?.addEventListener("click", downloadDependencyChecklist);
  document.getElementById("exportTaskButton")?.addEventListener("click", exportSelectedTask);
  document.getElementById("opsTaskForm")?.addEventListener("submit", createOpsTask);
  document.querySelectorAll("[data-select-task]").forEach((button) => button.addEventListener("click", () => {
    state.selectedTaskId = button.dataset.selectTask;
    render();
  }));
  document.querySelectorAll("[data-op-action]").forEach((button) => button.addEventListener("click", () => recordOpsAction(button.dataset.opAction)));
  document.getElementById("recoverTaskButton")?.addEventListener("click", recoverOpsTask);
  document.getElementById("resumePipelineButton")?.addEventListener("click", resumePipelineJob);
  document.getElementById("recoverPipelineButton")?.addEventListener("click", recoverPipelineJob);
  document.getElementById("suppressionForm")?.addEventListener("submit", addSuppression);

  document.querySelectorAll("[data-page-kind]").forEach((button) => button.addEventListener("click", async () => {
    const kind = button.dataset.pageKind;
    if (kind === "buyers") { state.buyerFilters.page = Number(button.dataset.page); await loadBuyers(); }
    if (kind === "contacts") { state.contactFilters.page = Number(button.dataset.page); await loadContacts(); }
    render();
  }));

  document.querySelectorAll("[data-token]").forEach((button) => button.addEventListener("click", () => {
    const textarea = document.getElementById("campaignBody");
    const token = button.dataset.token;
    const start = textarea.selectionStart;
    textarea.value = `${textarea.value.slice(0, start)}${token}${textarea.value.slice(textarea.selectionEnd)}`;
    textarea.focus();
    textarea.selectionStart = textarea.selectionEnd = start + token.length;
  }));

  document.getElementById("campaignForm")?.addEventListener("submit", saveCampaign);
  document.getElementById("aiDraftButton")?.addEventListener("click", generateDraft);
  document.getElementById("draftScenario")?.addEventListener("change", syncScenarioControls);
  document.querySelectorAll('input[name="emailAsset"]').forEach((input) => input.addEventListener("change", syncScenarioControls));
  document.querySelectorAll("[data-preview-campaign]").forEach((button) => button.addEventListener("click", () => previewCampaign(button.dataset.previewCampaign)));
  document.querySelectorAll("[data-review-campaign]").forEach((button) => button.addEventListener("click", () => reviewCampaign(button.dataset.reviewCampaign)));
  document.querySelectorAll("[data-approve-campaign]").forEach((button) => button.addEventListener("click", () => approveCampaign(button.dataset.approveCampaign)));
  document.querySelectorAll("[data-schedule-campaign]").forEach((button) => button.addEventListener("click", () => scheduleCampaign(button.dataset.scheduleCampaign)));
  document.querySelectorAll("[data-send-campaign]").forEach((button) => button.addEventListener("click", () => sendCampaign(button.dataset.sendCampaign)));
  syncScenarioControls();
}

async function generateDraft() {
  const button = document.getElementById("aiDraftButton");
  const status = document.getElementById("aiDraftStatus");
  const tradeContent = document.getElementById("tradeContent").value.trim();
  const companyBusiness = document.getElementById("companyBusiness").value.trim();
  const productFocus = document.getElementById("productFocus").value.trim();
  const hsCode = document.getElementById("hsCode").value.trim();
  if (!tradeContent || !companyBusiness || !productFocus || !hsCode) {
    toast("请先填写HSCode、产品方向、采购商证据和我方业务", "error");
    return;
  }
  const assetIds = selectedValues("emailAsset");
  const assetRightsConfirmed = document.getElementById("assetRightsConfirmed").checked;
  if (assetIds.length && !assetRightsConfirmed) {
    toast("选择配图后必须确认对外使用权", "error");
    return;
  }
  button.disabled = true;
  status.textContent = "正在生成草稿…";
  try {
    const draft = await api("/api/ai/draft", {
      method: "POST",
      body: JSON.stringify({
        scenario: document.getElementById("draftScenario").value,
        hsCode,
        productFocus,
        buyerCompany: document.getElementById("buyerCompany").value,
        contactName: document.getElementById("contactName").value,
        contactRole: document.getElementById("contactRole").value,
        buyerCountry: document.getElementById("campaignCountry").value,
        buyerEvidence: tradeContent,
        companyBusiness,
        senderCompany: document.getElementById("senderCompany").value,
        senderName: document.getElementById("senderName").value,
        tone: document.getElementById("draftTone").value,
        approvedClaims: selectedValues("approvedClaim"),
        assetIds,
        assetRightsConfirmed,
        eventName: document.getElementById("eventName").value,
        eventDates: document.getElementById("eventDates").value,
        eventBooth: document.getElementById("eventBooth").value,
        eventAddress: document.getElementById("eventAddress").value,
        meetingLocation: document.getElementById("meetingLocation").value,
        language: "English",
      }),
    });
    document.getElementById("campaignSubject").value = draft.subject;
    document.getElementById("campaignBody").value = draft.body;
    status.textContent = draft.warnings?.length
      ? `${draft.model} 已生成 · ${draft.wordCount}词 · ${draft.warnings.join("；")}`
      : `${draft.model} 已生成 · ${draft.wordCount}词 · 等待人工检查`;
    toast("AI草稿已写入主题和正文");
  } catch (error) {
    status.textContent = "生成失败";
    toast(error.message, "error");
  } finally {
    button.disabled = !state.health?.ai?.configured;
  }
}

async function saveCampaign(event) {
  event.preventDefault();
  const country = document.getElementById("campaignCountry").value;
  const priority = document.getElementById("campaignPriority").value;
  const highOnly = document.getElementById("highConfidenceOnly").checked;
  const payload = {
    name: document.getElementById("campaignName").value,
    subject: document.getElementById("campaignSubject").value,
    body: document.getElementById("campaignBody").value,
    brief: {
      scenario: document.getElementById("draftScenario").value,
      hsCode: document.getElementById("hsCode").value,
      productFocus: document.getElementById("productFocus").value,
      buyerEvidence: document.getElementById("tradeContent").value,
      contactRole: document.getElementById("contactRole").value,
      eventName: document.getElementById("eventName").value,
      eventDates: document.getElementById("eventDates").value,
      eventBooth: document.getElementById("eventBooth").value,
      eventAddress: document.getElementById("eventAddress").value,
      meetingLocation: document.getElementById("meetingLocation").value,
    },
    approvedClaims: selectedValues("approvedClaim"),
    assetIds: selectedValues("emailAsset"),
    assetRightsConfirmed: document.getElementById("assetRightsConfirmed").checked,
    filters: {
      countries: country ? [country] : [],
      priorities: priority ? [priority] : [],
      confidences: [],
      includeLowConfidence: !highOnly,
    },
    compliance: {
      suppressionListChecked: document.getElementById("suppressionChecked").checked,
      unsubscribeConfigured: document.getElementById("unsubscribeConfigured").checked,
      senderDomainVerified: document.getElementById("senderDomainVerified").checked,
      physicalAddressConfigured: document.getElementById("physicalAddressConfigured").checked,
    },
  };
  try {
    const campaign = await api("/api/campaigns", { method: "POST", body: JSON.stringify(payload) });
    await loadCampaigns();
    toast(`草稿已保存，预计 ${campaign.estimatedRecipients} 个候选邮箱`);
    render();
  } catch (error) { toast(error.message, "error"); }
}

async function previewCampaign(id) {
  try {
    state.campaignPreview = await api(`/api/campaigns/${id}/preview`, { method: "POST", body: "{}" });
    render();
    document.querySelector(".preview-list")?.scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (error) { toast(error.message, "error"); }
}

async function reviewCampaign(id) {
  try {
    await api(`/api/campaigns/${id}/submit-review`, { method: "POST", body: "{}" });
    await loadCampaigns(); render(); toast("活动已提交本地审核队列");
  } catch (error) { toast(error.message, "error"); }
}

async function approveCampaign(id) {
  const phrase = `APPROVE ${id}`;
  const confirmation = window.prompt(`批准活动前请确认短语：\n${phrase}`);
  if (confirmation !== phrase) {
    toast("批准已取消", "error");
    return;
  }
  try {
    await api(`/api/campaigns/${id}/approve`, {
      method: "POST",
      body: JSON.stringify({ confirm: phrase, reviewer: "local-admin" }),
    });
    await loadCampaigns();
    render();
    toast("活动已批准；真实发送仍需满足 SMTP 与验证门槛");
  } catch (error) { toast(error.message, "error"); }
}

async function scheduleCampaign(id) {
  try {
    await api(`/api/campaigns/${id}/simulate-schedule`, { method: "POST", body: JSON.stringify({}) });
    await loadCampaigns(); render(); toast("模拟排期已创建，不会发送邮件");
  } catch (error) { toast(error.message, "error"); }
}

async function sendCampaign(id) {
  const phrase = `SEND ${id}`;
  const confirmation = window.prompt(`即将发送下一安全批次。请输入确认短语：\n${phrase}`);
  if (confirmation !== phrase) {
    toast("发送已取消", "error");
    return;
  }
  try {
    const result = await api(`/api/campaigns/${id}/send`, {
      method: "POST",
      body: JSON.stringify({ confirm: phrase }),
    });
    await loadCampaigns();
    render();
    toast(`本批发送 ${result.batch.sent} 封，失败 ${result.batch.failed} 封，剩余 ${result.batch.remaining} 封`);
  } catch (error) {
    toast(error.message, "error");
  }
}

async function switchView(view) {
  state.view = view;
  sidebar.classList.remove("open");
  scrim.classList.remove("open");
  if (view === "buyers") await loadBuyers();
  if (view === "contacts") await loadContacts();
  if (view === "operations") await loadLocalControls();
  if (view === "campaigns") await loadCampaigns();
  render();
}

document.querySelectorAll(".nav-item").forEach((button) => button.addEventListener("click", () => switchView(button.dataset.view)));
document.getElementById("menuButton").addEventListener("click", () => { sidebar.classList.toggle("open"); scrim.classList.toggle("open"); });
scrim.addEventListener("click", () => { sidebar.classList.remove("open"); scrim.classList.remove("open"); });
document.getElementById("refreshButton").addEventListener("click", async () => {
  setLoading();
  try { await loadBase(); render(); toast("数据已刷新"); } catch (error) { main.innerHTML = emptyState("server-off", "无法连接本地服务", error.message); refreshIcons(); }
});

setLoading();
loadBase().then(render).catch((error) => {
  main.innerHTML = emptyState("server-off", "无法读取采集结果", error.message);
  refreshIcons();
});
